
*My website's URL:
https://d2j5sng1bjnike.cloudfront.net/
http://thiendn4-pj1-bucket.s3-website-us-west-2.amazonaws.com/
http://thiendn4-pj1-bucket.s3-website-us-west-2.amazonaws.com/index.html
